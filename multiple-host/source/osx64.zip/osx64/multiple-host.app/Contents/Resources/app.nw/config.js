/**
 * Created by leon on 16/2/23.
 */
module.exports = {
    "openPage": "https://github.com/liyangready/multiple-host", //每次打开的页面
}